/// <summary>
/// Authors: Jason Shull
/// Description: Script contains how the Company webpage will be formated
/// </summary>

import React from "react";

const SignUp = () => {
    return (
        <div>
            <h1>Insert Company Stuff Here</h1>
        </div>
    );
};

export default SignUp;