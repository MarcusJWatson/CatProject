import React from "react";
 
const Discover = () => {
    return (
        <div>
            <h1>
                Insert Discover Stuff Here
            </h1>
        </div>
    );
};
 
export default Discover;