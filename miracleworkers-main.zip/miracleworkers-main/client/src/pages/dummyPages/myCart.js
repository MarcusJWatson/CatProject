/* Author: Isa Luluquisin
// Description: Dummy page for myAccount
*/


import React from "react";
 
const MyCart = () => {
    return (
        <div>
            <h1>
                MyCart Dummy Page
            </h1>
        </div>
    );
};
 
export default MyCart;