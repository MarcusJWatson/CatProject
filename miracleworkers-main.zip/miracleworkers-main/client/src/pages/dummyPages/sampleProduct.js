/* Author: Isa Luluquisin
// Description: Dummy page for sampleproduct. This page is a filler for when a user 
// clicks on an image
*/


import React from "react";
 
const SampleProduct = () => {
    return (
        <div>
            <h1>
                Specific Product Page Here
            </h1>
        </div>
    );
};

export default SampleProduct;