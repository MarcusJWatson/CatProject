/* Author: Isa Luluquisin
// Description: Dummy page for myAccount
*/

import React from "react";
 
const MyAccount = () => {
    return (
        <div>
            <h1>
                Insert option to choose between seller and buyer page here!
            </h1>
        </div>
    );
};
 
export default MyAccount;