/* Author: Isa Luluquisin
// Description: Dummy page for myAccount
*/


import React from "react";
 
const MyFavorites = () => {
    return (
        <div>
            <h1>
                MyFavorites Dummy Page
            </h1>
        </div>
    );
};
 
export default MyFavorites;