/* Author: Amanda Everhart
// Description: Dummy page for myInbox
*/

import React from "react";
 
const MessagesInbox = () => {
    return (
        <div>
            <h1>
                Check your messages here!
            </h1>
        </div>
    );
};
 
export default MessagesInbox;