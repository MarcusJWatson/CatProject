/// <summary>
/// Authors: Jason Shull
/// Description: Script contains how the Home webpage will be formated
/// </summary>

import React from "react";

const Home = () => {
    return (
        <div>
            <h1>Insert Resources Stuff Here</h1>
        </div>
    );
};

export default Home;