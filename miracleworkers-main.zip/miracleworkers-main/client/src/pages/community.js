import React from "react";
 
const Community = () => {
    return (
        <div>
            <h1>
                Insert Community Stuff Here
            </h1>
        </div>
    );
};
 
export default Community;