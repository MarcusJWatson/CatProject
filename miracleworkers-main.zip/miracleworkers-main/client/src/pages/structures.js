/// <summary>
/// Authors: Jason Shull
/// Description: Script contains how the Structure webpage will be formated
/// </summary>

import React from "react";

const Dummy6 = () => {
    return (
        <div>
            <h1>
                Insert Structures Stuff Here
            </h1>
        </div>
    );
};

export default Dummy6;