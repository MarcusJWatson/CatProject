import React from "react";
 
const Support = () => {
    return (
        <div>
            <h1>
                Insert Support Stuff Here
            </h1>
        </div>
    );
};
 
export default Support;