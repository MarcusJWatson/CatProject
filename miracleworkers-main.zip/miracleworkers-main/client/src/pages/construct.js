import React from "react";
 
const Construct = () => {
    return (
        <div>
            <h1>
                Insert Construct Stuff Here
            </h1>
        </div>
    );
};
 
export default Construct;