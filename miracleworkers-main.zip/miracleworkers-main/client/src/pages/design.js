import React from "react";
 
const Design = () => {
    return (
        <div>
            <h1>
                Insert Design Stuff Here
            </h1>
        </div>
    );
};
 
export default Design;