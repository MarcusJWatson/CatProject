/// <summary>
/// Authors: Jason Shull
/// Description: Script contains how the Brand webpage will be formated
/// </summary>

import React from "react";

const About = () => {
    return (
        <div>
            <h1>
                Insert Brands Stuff Here
            </h1>
        </div>
    );
};

export default About;